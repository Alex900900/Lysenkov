package com.example.restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.*;

@SpringBootApplication
@RestController
@RequestMapping("/api")
public class RestaurantApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestaurantApplication.class, args);
    }

    // ===== ENTITY =====

    static class Visitor {
        Long id;
        String name;
        int age;
        String gender;

        public Visitor(Long id, String name, int age, String gender) {
            this.id = id;
            this.name = name;
            this.age = age;
            this.gender = gender;
        }
    }

    enum CuisineType {
        EUROPEAN, ITALIAN, CHINESE
    }

    static class Restaurant {
        Long id;
        String name;
        String description;
        CuisineType cuisineType;
        double averageCheck;
        BigDecimal rating;

        public Restaurant(Long id, String name, String description,
                          CuisineType cuisineType, double averageCheck, BigDecimal rating) {
            this.id = id;
            this.name = name;
            this.description = description;
            this.cuisineType = cuisineType;
            this.averageCheck = averageCheck;
            this.rating = rating;
        }
    }

    static class Review {
        Long visitorId;
        Long restaurantId;
        int rating;
        String text;

        public Review(Long visitorId, Long restaurantId, int rating, String text) {
            this.visitorId = visitorId;
            this.restaurantId = restaurantId;
            this.rating = rating;
            this.text = text;
        }
    }

    // ===== DTO =====

    record UserRequestDTO(String name, int age, String gender) {}
    record UserResponseDTO(Long id, String name, int age, String gender) {}

    record RestaurantRequestDTO(String name, String description, CuisineType cuisineType, double averageCheck) {}
    record RestaurantResponseDTO(Long id, String name, String description, CuisineType cuisineType, double averageCheck, BigDecimal rating) {}

    record ReviewRequestDTO(Long visitorId, Long restaurantId, int rating, String text) {}
    record ReviewResponseDTO(Long visitorId, Long restaurantId, int rating, String text) {}

    // ===== STORAGE =====

    List<Visitor> users = new ArrayList<>();
    List<Restaurant> restaurants = new ArrayList<>();
    List<Review> reviews = new ArrayList<>();

    Long userId = 1L;
    Long restaurantId = 1L;

    // ===== USERS =====

    @PostMapping("/users")
    public UserResponseDTO createUser(@RequestBody UserRequestDTO dto) {
        Visitor u = new Visitor(userId++, dto.name(), dto.age(), dto.gender());
        users.add(u);
        return new UserResponseDTO(u.id, u.name, u.age, u.gender);
    }

    @GetMapping("/users")
    public List<UserResponseDTO> getUsers() {
        List<UserResponseDTO> result = new ArrayList<>();
        for (Visitor u : users) {
            result.add(new UserResponseDTO(u.id, u.name, u.age, u.gender));
        }
        return result;
    }

    @DeleteMapping("/users/{id}")
    public void deleteUser(@PathVariable Long id) {
        users.removeIf(u -> u.id.equals(id));
    }

    // ===== RESTAURANTS =====

    @PostMapping("/restaurants")
    public RestaurantResponseDTO createRestaurant(@RequestBody RestaurantRequestDTO dto) {
        Restaurant r = new Restaurant(restaurantId++, dto.name(), dto.description(),
                dto.cuisineType(), dto.averageCheck(), BigDecimal.ZERO);

        restaurants.add(r);

        return new RestaurantResponseDTO(r.id, r.name, r.description, r.cuisineType, r.averageCheck, r.rating);
    }

    @GetMapping("/restaurants")
    public List<RestaurantResponseDTO> getRestaurants() {
        List<RestaurantResponseDTO> result = new ArrayList<>();

        for (Restaurant r : restaurants) {
            result.add(new RestaurantResponseDTO(r.id, r.name, r.description,
                    r.cuisineType, r.averageCheck, r.rating));
        }

        return result;
    }

    @DeleteMapping("/restaurants/{id}")
    public void deleteRestaurant(@PathVariable Long id) {
        restaurants.removeIf(r -> r.id.equals(id));
    }

    // ===== REVIEWS =====

    @PostMapping("/reviews")
    public ReviewResponseDTO createReview(@RequestBody ReviewRequestDTO dto) {
        Review review = new Review(dto.visitorId(), dto.restaurantId(), dto.rating(), dto.text());
        reviews.add(review);

        recalc(dto.restaurantId());

        return new ReviewResponseDTO(review.visitorId, review.restaurantId, review.rating, review.text);
    }

    @GetMapping("/reviews")
    public List<ReviewResponseDTO> getReviews() {
        List<ReviewResponseDTO> result = new ArrayList<>();

        for (Review r : reviews) {
            result.add(new ReviewResponseDTO(r.visitorId, r.restaurantId, r.rating, r.text));
        }

        return result;
    }

    // ===== RATING =====

    private void recalc(Long restaurantId) {
        int sum = 0;
        int count = 0;

        for (Review r : reviews) {
            if (r.restaurantId.equals(restaurantId)) {
                sum += r.rating;
                count++;
            }
        }

        if (count == 0) return;

        double avg = (double) sum / count;

        for (Restaurant r : restaurants) {
            if (r.id.equals(restaurantId)) {
                r.rating = BigDecimal.valueOf(avg);
            }
        }
    }
}
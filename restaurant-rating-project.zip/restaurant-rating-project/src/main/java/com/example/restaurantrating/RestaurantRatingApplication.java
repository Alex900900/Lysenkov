package com.example.restaurantrating;

import com.example.restaurantrating.entity.Restaurant;
import com.example.restaurantrating.entity.Review;
import com.example.restaurantrating.entity.Visitor;
import com.example.restaurantrating.enums.CuisineType;
import com.example.restaurantrating.service.RestaurantService;
import com.example.restaurantrating.service.ReviewService;
import com.example.restaurantrating.service.VisitorService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.math.BigDecimal;

@SpringBootApplication
public class RestaurantRatingApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestaurantRatingApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(VisitorService visitorService,
                                  RestaurantService restaurantService,
                                  ReviewService reviewService) {

        return args -> {

            Visitor visitor = new Visitor(1L, "Alex", 22, "Male");

            Restaurant restaurant = new Restaurant(
                    1L,
                    "Italian Pizza",
                    "Best pizza in city",
                    CuisineType.ITALIAN,
                    BigDecimal.valueOf(1200),
                    BigDecimal.ZERO
            );

            Review review = new Review(
                    1L,
                    1L,
                    5,
                    "Excellent!"
            );

            visitorService.save(visitor);
            restaurantService.save(restaurant);
            reviewService.save(review);

            System.out.println(restaurantService.findAll());
        };
    }
}

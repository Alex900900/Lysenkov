package com.example.restaurantrating.service;

import com.example.restaurantrating.entity.Restaurant;
import com.example.restaurantrating.entity.Review;
import com.example.restaurantrating.repository.RestaurantRepository;
import com.example.restaurantrating.repository.ReviewRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final RestaurantRepository restaurantRepository;

    public ReviewService(ReviewRepository reviewRepository,
                         RestaurantRepository restaurantRepository) {
        this.reviewRepository = reviewRepository;
        this.restaurantRepository = restaurantRepository;
    }

    public void save(Review review) {

        reviewRepository.save(review);
        updateRestaurantRating(review.getRestaurantId());
    }

    public void remove(Review review) {
        reviewRepository.remove(review);
    }

    public List<Review> findAll() {
        return reviewRepository.findAll();
    }

    private void updateRestaurantRating(Long restaurantId) {

        List<Review> reviews = reviewRepository.findAll();

        int sum = 0;
        int count = 0;

        for (Review review : reviews) {

            if (review.getRestaurantId().equals(restaurantId)) {
                sum += review.getRating();
                count++;
            }
        }

        double avg = (double) sum / count;

        for (Restaurant restaurant : restaurantRepository.findAll()) {

            if (restaurant.getId().equals(restaurantId)) {

                restaurant.setRating(
                        BigDecimal.valueOf(avg)
                                .setScale(2, RoundingMode.HALF_UP)
                );
            }
        }
    }
}

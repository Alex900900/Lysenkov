package com.example.restaurantrating.enums;

public enum CuisineType {
    EUROPEAN,
    ITALIAN,
    CHINESE,
    JAPANESE,
    AMERICAN
}
